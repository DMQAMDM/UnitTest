package DataOpsV1.UnitTest;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class UnitTest {

	// update your server details e.g. "jdbc:sqlserver://dataops-db.database.windows.net:1433;databaseName=DataMart"
	public String Azure_SQLServer_DM = "jdbc:sqlserver://{YourSQLServerAddress}:1433;databaseName={YourDBName}";
	// update your UserID e.g. String UserID = "DataAdmin"
	public String UserID = "{YourUserID}" ;
	// update your Password e.g. String Password = "Database2233#!@"
	public String Password = "{YourPassword}" ;


	@Test(priority=1)
	public void Verify_record_count_of_Customer_table() throws Exception {

		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");	
		Connection conn = DriverManager.getConnection(Azure_SQLServer_DM,UserID,Password);

		String sql = "select count(*) from dbo.customer";
		Statement statement = conn.createStatement();
		ResultSet resultSet = statement.executeQuery(sql);

		resultSet.next();
		int count = resultSet.getInt(1);
		System.out.println(count);

		AssertJUnit.assertEquals(847, count);

	}

	
	@Test(priority=2)
	public void Verify_record_count_of_CustomerCount_table() throws Exception {


		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");	
		Connection conn = DriverManager.getConnection(Azure_SQLServer_DM,UserID,Password);

		String sql = "select count(*) from dbo.customercount";
		Statement statement = conn.createStatement();
		ResultSet resultSet = statement.executeQuery(sql);

		resultSet.next();
		int count = resultSet.getInt(1);
		System.out.println(count);

		AssertJUnit.assertEquals(9, count);
	}
	
	@Test(priority=3)
	public void Verify_record_Upper_transformation_FirstName() throws Exception {


		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");	
		Connection conn = DriverManager.getConnection(Azure_SQLServer_DM,UserID,Password);

		String sql = "SELECT FirstName FROM [dbo].[Customer] where CustomerID = '1'";
		Statement statement = conn.createStatement();
		ResultSet resultSet = statement.executeQuery(sql);

		resultSet.next();
		String value = resultSet.getString(1);
		System.out.println(value);

		AssertJUnit.assertEquals("ORLANDO", value);
	}

	
	
	@Test(priority=4)
	public void Verify_record_CustomerCount_of_SalesPerson() throws Exception {


		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");	
		Connection conn = DriverManager.getConnection(Azure_SQLServer_DM,UserID,Password);

		String sql = "SELECT CustomerCount FROM [dbo].[CustomerCount] where SalesPerson = 'adventure-works\\linda3'";
		Statement statement = conn.createStatement();
		ResultSet resultSet = statement.executeQuery(sql);

		resultSet.next();
		String value = resultSet.getString(1);
		System.out.println(value);

		AssertJUnit.assertEquals("71", value);
	}
	
	
}
